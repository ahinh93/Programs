/**
 * Assignment 3
 * Andrew Hinh
 * This program creates the RectangleFrame object and sets it visible
 * @author ahinh
 *
 */
public class SwingRectangle {
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		RectangleFrame frame = new RectangleFrame();
		frame.setVisible(true);
	}


}
