/**
 * 
 * This class creates the UI
 * @author Landon Maupin and Andrew Hinh
 *
 */
public class SwingManager 
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ManagerFrame frame = new ManagerFrame();
		frame.setVisible(true);
	}

}
