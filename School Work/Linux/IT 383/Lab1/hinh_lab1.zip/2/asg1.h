#ifndef asg1_h_
#define asg1_h_
#include "stdlib.h"
#include "stdio.h"

#endif
