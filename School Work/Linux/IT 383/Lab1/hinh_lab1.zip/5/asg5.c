#ifndef asg5_h_
#define asg5_h_
#include "stdio.h"
#include "stdlib.h"
#include "fcntl.h"
#include "sys/stat.h"
#include "math.h"

int main()
{
	int counter;
	int in;
	int size;
	int arr[10];
	int fw;
	char buffer[BUFSIZ];
	FILE *fi;
	fw = open("output.txt", O_CREAT | O_RDWR, S_IWRITE | S_IREAD,0777);
	for(counter = 0; counter < 10; counter++)
	{
		printf("arr[%d]=? ",counter);
		scanf("%d,",&in);
		arr[counter] = in;
		size = sprintf(buffer,"%d",arr[counter]);
		write(fw,buffer,size);		
		//write new line
		write(fw,"\n",sizeof(char));
	}
	printf("Reverse order of list: \n");
	for(counter = 9; counter >= 0; counter--)
	{
		printf("arr[%d]= %d\n",counter,arr[counter]);
	}
	close(fw);
	return 0;
}

#endif
